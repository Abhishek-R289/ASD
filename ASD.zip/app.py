from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from PIL import Image, UnidentifiedImageError
import os, uuid, requests
import numpy as np
import tensorflow as tf
import cv2

# ---- CONFIGURATION ----
UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
MAX_CONTENT_LENGTH = 6 * 1024 * 1024
MODEL_PATH = os.environ.get('MODEL_PATH', 'model.h5')
GOOGLE_API_KEY = os.environ.get('GOOGLE_API_KEY')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
app.secret_key = os.environ.get('ASD_SECRET', 'asd_secret_key')

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ---- LOAD MODEL ----
try:
    model = tf.keras.models.load_model(MODEL_PATH)
except Exception:
    model = None

# ---- FACE DETECTOR (Haar Cascade) ----
# Using OpenCV's bundled haarcascade file. This requires opencv-python package.
FACE_CASCADE_PATH = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)


# ---- HELPERS ----
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def detect_faces_and_crop(pil_image):
    """
    Detect faces in a PIL Image (RGB). If exactly one face is detected and it's sufficiently large,
    crop to that face (with padding) and return the cropped PIL Image.
    Returns: cropped_pil_image or None (if none/multiple faces or face too small)
    """
    # Convert PIL -> numpy RGB array
    rgb = np.array(pil_image)
    h, w = rgb.shape[:2]

    # convert to gray for detection
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

    # set a reasonable minimum face size relative to the image
    min_face_w = max(30, int(w * 0.12))  # at least 12% of width or 30px
    min_face_h = max(30, int(h * 0.12))

    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(min_face_w, min_face_h)
    )

    if len(faces) == 0:
        return None  # no face found
    if len(faces) > 1:
        return "MULTIPLE"  # more than one face found

    # exactly one face
    (x, y, fw, fh) = faces[0]

    # ensure face is not tiny (area threshold) - require at least e.g. 1.5% of image area
    face_area = fw * fh
    img_area = w * h
    if face_area / img_area < 0.015:
        return None

    # add padding to crop (so eyes/chin not clipped)
    pad_x = int(fw * 0.25)
    pad_y = int(fh * 0.30)

    x1 = max(0, x - pad_x)
    y1 = max(0, y - pad_y)
    x2 = min(w, x + fw + pad_x)
    y2 = min(h, y + fh + pad_y)

    cropped_rgb = rgb[y1:y2, x1:x2]
    cropped_pil = Image.fromarray(cropped_rgb)
    return cropped_pil


# ---- ROUTES ----
@app.route('/')
def welcome():
    """Welcome landing page"""
    return render_template('welcome.html')


@app.route('/patient', methods=['GET', 'POST'])
def patient():
    """Patient details form"""
    if request.method == 'POST':
        name = request.form['patient_name']
        age = request.form['age']
        gender = request.form['gender']
        return render_template('analyze.html', patient_name=name, age=age, gender=gender)
    return render_template('patient.html')


@app.route('/analyze')
def analyze():
    """Display the image upload form"""
    return render_template('analyze.html')


@app.route('/upload', methods=['POST'])
def upload():
    """Handle image upload and model prediction"""
    if model is None:
        flash('Model not found. Train and save model.h5 before running the app.')
        return redirect(url_for('welcome'))

    if 'image' not in request.files:
        flash('No image uploaded.')
        return redirect(url_for('analyze'))

    file = request.files['image']
    if file.filename == '':
        flash('No file selected.')
        return redirect(url_for('analyze'))

    if not allowed_file(file.filename):
        flash('Unsupported file type. Please upload PNG/JPG/JPEG.')
        return redirect(url_for('analyze'))

    ext = os.path.splitext(secure_filename(file.filename))[1].lower()
    filename = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    try:
        pil_img = Image.open(file.stream).convert('RGB')
    except UnidentifiedImageError:
        flash('Invalid image file.')
        return redirect(url_for('analyze'))
    except Exception:
        flash('Could not open image.')
        return redirect(url_for('analyze'))

    # ---- FACE DETECTION: ensure exactly one clear human face is present ----
    face_result = detect_faces_and_crop(pil_img)
    if face_result is None:
        flash('No clear human face detected. Please upload a only  face image.')
        return redirect(url_for('analyze'))
    if face_result == "MULTIPLE":
        flash('Multiple faces detected. Please upload an image containing only one person\'s face.')
        return redirect(url_for('analyze'))

    # face_result is a cropped PIL image (face only) -> save this cropped image and continue
    try:
        # save cropped face image so UI shows the face area
        face_result.save(path)
    except Exception as e:
        flash('Failed to save uploaded image.')
        return redirect(url_for('analyze'))

    # prepare array for model (resize to 224x224 like training)
    img_for_model = face_result.resize((224, 224))
    arr = np.asarray(img_for_model, dtype=np.float32) / 255.0
    arr = np.expand_dims(arr, axis=0)

    # ---- Prediction ----
    try:
        pred = model.predict(arr)
    except Exception as e:
        flash('Prediction failed. Check model compatibility.')
        return redirect(url_for('analyze'))

    if pred.shape[-1] == 1:
        prob = float(pred[0][0])
    else:
        # assume binary with two outputs (prob for class 1 at index 1)
        prob = float(pred[0][1])

    # You previously used threshold 0.001; preserve that logic
    label = 'Autistic' if prob >= 0.001 else 'Non-Autistic'

    # ---- Nearby Specialists ----
    places = []
    if label == 'Autistic':
        lat = request.form.get('lat')
        lng = request.form.get('lng')
        if GOOGLE_API_KEY and lat and lng:
            url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
            params = {
                "key": GOOGLE_API_KEY,
                "location": f"{lat},{lng}",
                "radius": 20000,
                "keyword": "pediatric developmental specialist"
            }
            try:
                res = requests.get(url, params=params, timeout=6)
                data = res.json()
                for p in data.get('results', [])[:5]:
                    places.append({
                        'name': p.get('name'),
                        'vicinity': p.get('vicinity'),
                        'maps_url': f"https://www.google.com/maps/place/?q=place_id:{p.get('place_id')}"
                    })
            except Exception:
                pass

    # Render results on analyze.html
    return render_template(
        'analyze.html',
        filename=filename,
        prob=round(prob, 3),
        label=label,
        places=places,
        patient_name=request.form.get('patient_name'),
        age=request.form.get('age'),
        gender=request.form.get('gender')
    )


@app.route('/static/uploads/<path:filename>')
def uploaded_file(filename):
    """Serve uploaded images"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# ---- RUN APP ----
if __name__ == '__main__':
    app.run(debug=True)
